#!/usr/bin/env python
# coding: utf-8

# In[1]:


from tqdm import tqdm
import string

from nltk.tokenize import TweetTokenizer # a tweet tokenizer from nltk.
tokenizer = TweetTokenizer()


import warnings
warnings.filterwarnings('ignore')

import re
tqdm.pandas(desc="progress-bar")
import spacy
nlp = spacy.load('en')


# In[2]:


import pandas as pd
df = pd.read_csv('final_data.csv')
df.shape


# In[3]:


df = df[pd.notnull(df['Tweet'])]


# In[4]:


from sklearn.utils import shuffle
df = shuffle(df)


# In[5]:


col = ['Category', 'Tweet']
df = df[col]


# In[6]:


df.columns = ['Category', 'Tweet']


# In[7]:


def clean_text_round1(text):
    text = text.lower()
    text = re.sub('\[.*?\]', '', text)
    text = re.sub('[%s]' % re.escape(string.punctuation), '', text)
    text = re.sub('\w*\d\w*', '', text)
    return text


# In[8]:


def clean_text_round2(text):
    '''Get rid of some additional punctuation and non-sensical 
    text that was missed the first time around.'''
    text = re.sub('[‘’“”…]', '', text)
    text = re.sub('\n', '', text)
    return text


# In[9]:


from generator import*
from cleaner import *

data_xml=[]

stop_words = ['ourselves', 'hers', 'between', 'yourself', 
              'but', 'again', 'there', 'about', 'once', 
              'during', 'out', 'very', 'with', 'they',
              'own', 'an', 'be', 'some', 'for', 'do', 'its', 
              'yours', 'such', 'into', 'of', 'most', 'itself',
              'other', 'off', 'is', 's', 'am', 'or', 'who', 'as', 
              'from', 'him', 'each', 'the', 'themselves', 'until', 
              'below', 'are', 'we', 'these', 'your', 'his', 'through', 'don',
              'nor', 'me', 'were', 'her', 'more', 'himself', 'this', 'down', 
              'should', 'our', 'their', 'while', 'above', 'both', 'up', 'to', 'ours', 
              'she', 'all', 'no', 'when', 'at', 'any', 'before', 'them', 'same', 'and', 
              'been', 'in', 'will', 'on', 'does', 'yourselves', 'then', 'that', 'because',
              'what', 'over', 'why', 'so', 'can', 'did', 'not', 'now', 'under', 'he', 'you',
              'herself', 'just', 'where', 'too', 'only', 'myself', 'which', 'those', 'i', 'after',
              'few', 'whom', 't', 'being', 'if', 'theirs', 'my', 'against', 'a', 'by', 'doing', 'it', 
              'how', 'further', 'was', 'here', 'than']

def tokenize(tweet):
    tweet = nlp(tweet)
    tweet = negation_tag(tweet)
    tweet = ' '.join(tweet)
    tweet = clean_text_round1(tweet)
    tweet = clean_text_round2(tweet)
    tokens = tokenizer.tokenize(tweet.lower())
    tokens = [w for w in tokens if not w in stop_words]
    
    try:
        temp=[]
        tokens = list(filter(lambda t: not t.startswith('@'), tokens))
        tokens = list(filter(lambda t: not t.startswith('#'), tokens))
        tokens = list(filter(lambda t: not t.startswith('http'), tokens))
        tokens = list(filter(lambda t: not t.startswith('www'), tokens))
        temp.append(tokens)
        data_xml.append(temp)
        

        return tokens
    except:
        return 'NC'


# In[10]:


def postprocess(data, n=3000):
    data = data.head(n)
    data['tokens'] = data['Tweet'].progress_map(tokenize) 
    data = data[data.tokens != 'NC']
    data.reset_index(inplace=True)
    return data

data = postprocess(df)


# In[11]:


data.shape


# ### Construction des mots embarqués

# In[12]:


from sklearn.model_selection import train_test_split
import numpy as np


# In[13]:


x_train, x_test, y_train, y_test = train_test_split(np.array(data.head(93170).tokens),
                                   np.array(data.head(93170).Tweet), test_size=0.2)


# In[14]:


import gensim
from gensim.models.word2vec import Word2Vec 
LabeledSentence = gensim.models.doc2vec.LabeledSentence


# In[15]:


def labelizeTweets(tweets, label_type):
    labelized = []
    for i,v in tqdm(enumerate(tweets)):
        label = '%s_%s'%(label_type,i)
        labelized.append(LabeledSentence(v, [label]))
    return labelized

x_train = labelizeTweets(x_train, 'TRAIN')
x_test = labelizeTweets(x_test, 'TEST')


# In[16]:


tweet_w2v = Word2Vec(size=150, min_count=20,sg=0)#sg=1: skip-gram, 0: cbow
tweet_w2v.build_vocab([x.words for x in tqdm(x_train)])
tweet_w2v.train([x.words for x in tqdm(x_train)], 
                total_examples=tweet_w2v.corpus_count, epochs=tweet_w2v.iter)


# In[17]:


import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')

import pandas as pd
from sklearn.decomposition import PCA

def plot_words(words):
    word_vecs = [tweet_w2v[word] for word in words]
    pca = PCA(n_components=2)

    columns = ["Component1","Component2"]
    df = pd.DataFrame(pca.fit_transform(word_vecs), columns=columns, index=words)
    def annotate_df(row):  
        ax.annotate(row.name, list(row.values),
                    xytext=(10,-5), 
                    textcoords='offset points',
                    size=12, 
                    color='black')

    ax = df.plot(kind="scatter",x='Component1', y='Component2',)
    _ = df.apply(annotate_df, axis=1)
    plt.savefig('outputcb.jpg')


# In[18]:


words=['meningitis', 'have']

plot_words(words)


# ## Transformation des Tweet en Espace Vectoriel

# In[19]:


from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import TfidfVectorizer


# In[20]:


print('building tf-idf matrix ...')
vectorizer = TfidfVectorizer(analyzer=lambda x: x, min_df=0)
matrix = vectorizer.fit_transform([x.words for x in x_train])
tfidf = dict(zip(vectorizer.get_feature_names(), vectorizer.idf_))
print('vocab size :', len(tfidf))


# In[21]:


def buildWordVector(tokens, size):
    vec = np.zeros(size).reshape((1, size))
    count = 0.
    for word in tokens:
        try:
            vec += tweet_w2v[word].reshape((1, size)) * tfidf[word]
            count += 1.
        except KeyError: # handling the case where the token is not
                         # in the corpus. useful for testing.
            continue
    if count != 0:
        vec /= count
    return vec


# In[66]:


from sklearn.preprocessing import scale
vectors = np.concatenate([buildWordVector(z, 150) for z in tqdm(map(lambda x: x, data.Tweet))])
labels=[label for label in  data.Category]
vectors = scale(vectors)


# In[67]:


data.shape


# ## ANN

# In[68]:


X_train, X_test, y_train, y_test, indices_train, indices_test = train_test_split(features, labels, data.index, test_size=0.33, random_state=0)


# In[69]:


X_train[1000]


# In[70]:


from sklearn import preprocessing
encoder = preprocessing.LabelBinarizer()
encoder.fit(y_train)
y_train = encoder.transform(y_train)
y_test = encoder.transform(y_test)


# ### Keras

# In[71]:


from keras.models import Sequential
from keras.layers import Dense, Activation
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import GridSearchCV


# In[72]:


model= Sequential()


# In[73]:


model.add(Dense(512, input_shape=(150,)))
model.add(Activation('relu'))


# In[74]:


model.add(Dense(5))
model.add(Activation('softmax'))


# In[75]:


model.compile(loss='categorical_crossentropy', 
              optimizer='rmsprop', 
              metrics=['accuracy'])


# In[76]:


history = model.fit(X_train, y_train, 
                    batch_size=100, 
                    epochs=150, 
                    verbose=1, 
                    validation_split=0.1)


# In[77]:


# summarize history for accuracy
plt.plot(history.history['acc'])
plt.plot(history.history['val_acc'])
plt.title('Model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.savefig('accuracy.jpg',  bbox_inches = "tight")
plt.show()
# summarize history for loss
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()


# # Faire de la prediction

# In[78]:


labels[1]


# In[79]:


for i in range(10):    
    prediction = model.predict(np.array([X_test[i]]))
    print(prediction)


# In[80]:


labels[0]


# In[90]:


i=3
text_labels = encoder.classes_ 
predicted_label = labels[np.argmax(prediction[0])]

print(data.Tweet.iloc[i], "...")
print("===========================================================")
print('Actual label:' + str(labels[i]))
print("Predicted label: " + predicted_label)


# ## Reglage des paramètres

# In[91]:


def create_model(optimizer='adam', activation='relu'):
   # create model
    model = Sequential()
    model.add(Dense(512, input_shape=(150,), activation=activation))
    model.add(Dense(5, activation='softmax'))
    # Compile model
    model.compile(loss='categorical_crossentropy', optimizer=optimizer, metrics=['accuracy'])
    return model


# In[93]:


model = KerasClassifier(build_fn=create_model, verbose=0)
batch_size = [10, 20, 40]
epochs = [10, 50, 150]

optimizer = ['Adam', 'Adamax', 'Nadam']

activation = ['softmax', 'relu', 'tanh']

param_grid = dict(optimizer=optimizer, batch_size=batch_size, nb_epoch=epochs, activation=activation)
grid = GridSearchCV(estimator=model, param_grid=param_grid, n_jobs=-1)
grid_result = grid.fit(X_train, y_train)
# summarize results
print("Best: %f using %s" % (grid_result.best_score_, grid_result.best_params_))
means = grid_result.cv_results_['mean_test_score']
stds = grid_result.cv_results_['std_test_score']
params = grid_result.cv_results_['params']
for mean, stdev, param in zip(means, stds, params):
    print("%f (%f) with: %r" % (mean, stdev, param))


# In[ ]:




