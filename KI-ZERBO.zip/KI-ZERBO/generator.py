from infection import *
from lxml import etree as ET
import xml.etree.cElementTree as ET


rfile = open(r'triggers.txt')
irules = sortRules(rfile.readlines())
def generator_vec(doc):
    data_xml=[]
    #root = ET.Element("Data")
    doc.user_data=set()
    if len(list(doc.sents))==1:
        for sent in doc.sents:
            ph= set(doc.user_data)
            for word in sent:
                if word.pos_!='ADP' and word.pos_!='PUNCT':
                    ph.add(word.text)
            tagger = infTagger(sentence = sent.text, phrases = list(ph),rules = irules, negP=False)
            vec = tagger.getVector()

            data_xml.append(vec[9])
            data_xml.append(vec[0])
            data_xml.append(vec[1])
            data_xml.append(vec[2])
            data_xml.append(vec[3])
            data_xml.append(vec[4])
            data_xml.append(vec[5])
            data_xml.append(vec[6])
            data_xml.append(vec[7])
            data_xml.append(vec[8])
    
    return data_xml

#define a new pipleline including the negation_tag component
def custom_pipeline(nlp):
    return (nlp.tagger,nlp.parser,generator_vec)

#need to re-initlaize spaCy with the new pipeline
nlp_neg = spacy.load('en', create_pipeline=custom_pipeline)



