# Python bytecode 2.7 (62211)
# Embedded file name: /Users/thierrybayala/Desktop/Workspace/Kafka/normalizer.py
# Compiled at: 2019-01-13 04:04:27
# Decompiled by https://python-decompiler.com
import re, spacy
from spacy.symbols import nsubj, VERB
import pandas as pd
nlp = spacy.load('en')
from difflib import SequenceMatcher

def sortRules(ruleList):
    ruleList.sort(key=len, reverse=True)
    sortedList = []
    for rule in ruleList:
        s = rule.strip().split('\t')
        splitTrig = s[0].split()
        trig = ('\\s+').join(splitTrig)
        pattern = '\\b(' + trig + ')\\b'
        s.append(re.compile(pattern, re.IGNORECASE))
        sortedList.append(s)

    return sortedList


def getdependencies(doc):
    pairs = []
    for possible_subject in doc:
        if possible_subject.dep == nsubj and possible_subject.head.pos == VERB:
            pairs.append((possible_subject, possible_subject.head))

    for pair in pairs:
        return pair


def convert_to_doc(text):
    doc = nlp(text)
    return doc


def returnsentneces(doc):
    data = []
    for sent in doc.sents:
        data.append(sent.text.replace('\n', ''))

    return data


def removeBigining(token):
    m = re.search("b'(.*)", token)
    if m:
        found = m.group(1)
        return found
    return token


def removeBiginingb(token):
    m = re.search('b"(.*)', token)
    if m:
        found = m.group(1)
        return found
    return token


def lookForHastag(token):
    regex = re.compile('[@_!#$%^&*()<>?/\\|}{~:]')
    if regex.search(token) == None:
        return 0
    return 1
    return


def duplication_removal(L, K):
    data = []
    checList = []
    for i, text1 in enumerate(L):
        for j, text2 in enumerate(K):
            if j not in checList:
                ratio = SequenceMatcher(None, text1, text2).ratio()
                if ratio > 0.8:
                    if i != j:
                        checList.append(i)
                        temp = []
                        temp.append(i)
                        temp.append(j)
                        data.append(temp)

    return checList


def findTrueExp(token):
    m = re.search('\\[(.*?)\\]', token)
    if m:
        word = str(m.group(1)).split('-')
        word = (' ').join(word)
        return word


def checDoesExp(token):
    m = re.search('doesn(.*)', token)
    if m:
        return 'does not'
    return token


def findPunctuation(token):
    return re.sub('[^\\w\\s]', '', token)


class negTagger(object):

    def __init__(self, sentence='', phrases=None, rules=None, negP=True):
        self.__sentence = sentence
        self.__phrases = phrases
        self.__rules = rules
        self.__negTaggedSentence = ''
        self.__scopesToReturn = []
        self.__negationFlag = None
        self.__test_value = []
        filler = '_'
        for i, rule in enumerate(self.__rules):
            reformatRule = re.sub('\\s+', filler, rule[0].strip())
            self.__sentence = rule[5].sub(' ' + rule[2].strip() + rule[4] + reformatRule + rule[2].strip() + ' ', self.__sentence)

        for phrase in self.__phrases:
            phrase = re.sub('([.^$*+?{\\\\|()[\\]])', '\\\\\\1', phrase)
            splitPhrase = phrase.split()
            joiner = '\\W+'
            joinedPattern = '\\b' + joiner.join(splitPhrase) + '\\b'
            reP = re.compile(joinedPattern, re.IGNORECASE)
            m = reP.search(self.__sentence)
            if m:
                self.__sentence = self.__sentence.replace(m.group(0), '[PHRASE]' + re.sub('\\s+', filler, m.group(0).strip()) + '[PHRASE]')

        overlapFlag = 0
        prenFlag = 0
        postFlag = 0
        prePossibleFlag = 0
        postPossibleFlag = 0
        sentenceTokens = self.__sentence.split()
        sentencePortion = ''
        aScopes = []
        sb = []
        for i in range(len(sentenceTokens)):
            word = sentenceTokens[i].replace('[PHRASE]', '')
            word = removeBigining(word)
            word = removeBiginingb(word)
            word = checDoesExp(word)
            if lookForHastag(word) != 1:
                self.__test_value.append(word)
            else:
                self.__test_value.append('')
            if sentenceTokens[i][:6] == '[APOS]':
                temp = sentenceTokens[i].replace('[APOS]', '')
                temp = temp.replace('[PHRASE]', '')
                temp = removeBigining(temp)
                temp = removeBiginingb(temp)
                temp = checDoesExp(temp)
                self.__test_value[i] = findTrueExp(temp)
                prenFlag = 1
                overlapFlag = 0
            if sentenceTokens[i][:6] in ('[CONJ]', '[PSEU]', '[POST]', '[PREP]', '[POSP]'):
                overlapFlag = 1
            if i + 1 < len(sentenceTokens):
                if sentenceTokens[i + 1][:6] == '[APOS]':
                    overlapFlag = 1
                    if sentencePortion.strip():
                        aScopes.append(sentencePortion.strip())
                    sentencePortion = ''
            if prenFlag == 1 and overlapFlag == 0:
                sentenceTokens[i] = sentenceTokens[i].replace('[PHRASE]', '[NEGATED]')
                sentencePortion = sentencePortion + ' ' + sentenceTokens[i]
            sb.append(sentenceTokens[i])

        if sentencePortion.strip():
            aScopes.append(sentencePortion.strip())
        sentencePortion = ''
        sb.reverse()
        sentenceTokens = sb
        sb2 = []
        for i in range(len(sentenceTokens)):
            if sentenceTokens[i][:6] == '[POST]':
                postFlag = 1
                overlapFlag = 0
            if sentenceTokens[i][:6] in ('[CONJ]', '[PSEU]', '[APOS]', '[PREP]', '[POSP]'):
                overlapFlag = 1
            if i + 1 < len(sentenceTokens):
                if sentenceTokens[i + 1][:6] == '[POST]':
                    overlapFlag = 1
                    if sentencePortion.strip():
                        aScopes.append(sentencePortion.strip())
                    sentencePortion = ''
            if postFlag == 1 and overlapFlag == 0:
                sentenceTokens[i] = sentenceTokens[i].replace('[PHRASE]', '[NEGATED]')
                sentencePortion = sentenceTokens[i] + ' ' + sentencePortion
            sb2.insert(0, sentenceTokens[i])

        if sentencePortion.strip():
            aScopes.append(sentencePortion.strip())
        sentencePortion = ''
        self.__negTaggedSentence = (' ').join(sb2)
        if negP:
            sentenceTokens = sb2
            sb3 = []
            for i in range(len(sentenceTokens)):
                if sentenceTokens[i][:6] == '[PREP]':
                    prePossibleFlag = 1
                    overlapFlag = 0
                if sentenceTokens[i][:6] in ('[CONJ]', '[PSEU]', '[POST]', '[APOS]',
                                             '[POSP]'):
                    overlapFlag = 1
                if i + 1 < len(sentenceTokens):
                    if sentenceTokens[i + 1][:6] == '[PREP]':
                        overlapFlag = 1
                        if sentencePortion.strip():
                            aScopes.append(sentencePortion.strip())
                        sentencePortion = ''
                if prePossibleFlag == 1 and overlapFlag == 0:
                    sentenceTokens[i] = sentenceTokens[i].replace('[PHRASE]', '[POSSIBLE]')
                    sentencePortion = sentencePortion + ' ' + sentenceTokens[i]
                sb3 = sb3 + ' ' + sentenceTokens[i]

            if sentencePortion.strip():
                aScopes.append(sentencePortion.strip())
            sentencePortion = ''
            sb3.reverse()
            sentenceTokens = sb3
            sb4 = []
            for i in range(len(sentenceTokens)):
                if sentenceTokens[i][:6] == '[POSP]':
                    postPossibleFlag = 1
                    overlapFlag = 0
                if sentenceTokens[i][:6] in ('[CONJ]', '[PSEU]', '[APOS]', '[PREP]',
                                             '[POST]'):
                    overlapFlag = 1
                if i + 1 < len(sentenceTokens):
                    if sentenceTokens[i + 1][:6] == '[POSP]':
                        overlapFlag = 1
                        if sentencePortion.strip():
                            aScopes.append(sentencePortion.strip())
                        sentencePortion = ''
                if postPossibleFlag == 1 and overlapFlag == 0:
                    sentenceTokens[i] = sentenceTokens[i].replace('[PHRASE]', '[POSSIBLE]')
                    sentencePortion = sentenceTokens[i] + ' ' + sentencePortion
                sb4.insert(0, sentenceTokens[i])

            if sentencePortion.strip():
                aScopes.append(sentencePortion.strip())
            self.__negTaggedSentence = (' ').join(sb4)
        if '[NEGATED]' in self.__negTaggedSentence:
            self.__negationFlag = 'negated'
        else:
            if '[POSSIBLE]' in self.__negTaggedSentence:
                self.__negationFlag = 'possible'
            else:
                self.__negationFlag = 'affirmed'
        self.__negTaggedSentence = self.__negTaggedSentence.replace(filler, ' ')
        for line in aScopes:
            tokensToReturn = []
            thisLineTokens = line.split()
            for token in thisLineTokens:
                if token[:6] not in ('[APOS]', '[PREP]', '[POST]', '[POSP]'):
                    tokensToReturn.append(token)

            self.__scopesToReturn.append((' ').join(tokensToReturn))

        return

    def getNegTaggedSentence(self):
        return self.__sentence.split()

    def getNegationFlag(self):
        return self.__negationFlag

    def getScopes(self):
        return self.__scopesToReturn

    def getNoApos(self):
        return (' ').join(filter(None, self.__test_value))

    def __str__(self):
        text = self.__negTaggedSentence
        text += '\t' + self.__negationFlag
        text += '\t' + ('\t').join(self.__scopesToReturn)